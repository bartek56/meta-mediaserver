from __future__ import unicode_literals
import sys
import getopt
import os
from mutagen.easyid3 import EasyID3
from mutagen.mp3 import MP3

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def convert_song_name(songName):
    songName = songName.replace(" -", " - ")
    songName = songName.replace("- ", " - ")

    songName = songName.replace("(Oficial Video HD)", "")
    songName = songName.replace("(Official Video HD)", "")
    songName = songName.replace("[Official Video HD]", "")
    songName = songName.replace("[Official Music Video]", "")
    songName = songName.replace("(Official Music Video)", "")

    songName = songName.replace("(Official Lyric Video)", "")

    songName = songName.replace("( Official Video )", "")
    songName = songName.replace("(Official Video)", "")
    songName = songName.replace("[Official Video]", "")
    songName = songName.replace("(official video)", "")
    songName = songName.replace("(Official video)", "")
    songName = songName.replace("[OFFICIAL VIDEO]", "")
    songName = songName.replace("(OFFICIAL VIDEO)", "")
    songName = songName.replace("(Video Official)", "")
    songName = songName.replace("[Video Official]", "")
    songName = songName.replace("(VIDEO OFFICIAL)", "")
      
    songName = songName.replace("(Oficial Video)", "")
    songName = songName.replace("[Oficial Video]", "")
    songName = songName.replace("(OFICIAL VIDEO)", "")
    songName = songName.replace("(Video Oficial)", "")
    songName = songName.replace("[Video Oficial]", "")
    songName = songName.replace("(VIDEO OFICIAL)", "")
  
    songName = songName.replace("Video Oficial", "")
    songName = songName.replace("Video Official", "")
    songName = songName.replace("Oficial Video", "")
    songName = songName.replace("Official Video", "")
    
    songName = songName.replace("(Oficjalne Video)", "")
    songName = songName.replace("Oficjalne Video", "")
    songName = songName.replace("(oficjalne video)", "")
    songName = songName.replace("oficjalne video", "")

    songName = songName.replace("(Oficjalne Wideo)", "")
    songName = songName.replace("Oficjalne Wideo", "")
    songName = songName.replace("(oficjalne wideo)", "")
    songName = songName.replace("oficjalne wideo", "")

   
   
    songName = songName.replace("(Audio)", "")

    songName = songName.replace("(Official Audio)", "")
    songName = songName.replace("[Official Audio]", "")

    songName = songName.replace("   ", " ")   
    songName = songName.replace("  ", " ")   
    songName = songName.replace("  ", " ")   
    songName = songName.replace(" _", "")

    return songName

def rename_song_name(songName):
    songName = convert_song_name(songName)
    ext = ".xyz"
    songName = "%s%s"%(songName,ext)

    songName = songName+".xyz"
    songName = songName.replace("  .xyz", ".xyz")
    songName = songName.replace(" .xyz", ".xyz")
    songName = songName.replace(".xyz", "")
    
    return songName

def rename_song_file(path, fileName):

    originalFileName = fileName 
    
    fileName = convert_song_name(fileName)

    fileName = fileName.replace("  .mp3", ".mp3")
    fileName = fileName.replace(" .mp3", ".mp3")

    originalFileNameWithPath=os.path.join(path, originalFileName)
    fileNameWithPath = os.path.join(path, fileName)
    os.rename(originalFileNameWithPath, fileNameWithPath)

    return fileName

def convert_songname_on_metadata(songName):
    slots = songName.split(" - ")
    metadata ={ 'tracknumber': "1",}
    if len(slots) == 2:
      metadata['artist'] = slots[0]
      metadata['title'] = slots[1]
    elif len(slots) < 2:
      slots = songName.split("-")
      if len(slots) == 2:
        metadata['artist'] = slots[0]
        metadata['title'] = slots[1]
      else:
        metadata['title'] = songName
        metadata['artist'] = ""
    else:
      metadata['artist'] = slots[0]
      name=""
      i=0
      for slots2 in slots:
        if i > 0:
          if i > 1:
            name+="-"
          name+=slots[i]
        i=i+1  
      metadata['title'] = name

    return metadata


def update_metadata(PLAYLISTS_PATH, playlistName):
      path=PLAYLISTS_PATH+playlistName
      albumName="YT "+playlistName

      filesList = [f for f in os.listdir(path) if f.endswith(".mp3")]
      for x in range(len(filesList)):
        originalFileName = filesList[x]

        newFileName = rename_song_file(path, originalFileName)
        newSongName = newFileName.replace(".mp3", "")
        
        metadataSongName = convert_songname_on_metadata(newSongName)
        newFileNameWithPath = os.path.join(path, newFileName)
        if not os.path.isfile(newFileNameWithPath):
            warningInfo="WARNING: %s not exist"%(newFileName)
            warnings.warn(warningInfo, Warning)
            print(bcolors.WARNING + warningInfo + bcolors.ENDC)
            continue
        metatag = EasyID3(newFileNameWithPath)
        metatag['album'] = albumName
        metatag['artist'] = metadataSongName['artist']
        metatag['title'] = metadataSongName['title']
        metatag.save()
        print(bcolors.OKGREEN + "[ID3] Added metadata" + bcolors.ENDC)
        audio = MP3(newFileNameWithPath, ID3=EasyID3)
        print (newFileNameWithPath)
        print (audio.pprint())


def update_metadata_from_YTplaylist(url, PLAYLISTS_PATH, playlistName):
    path=PLAYLISTS_PATH+playlistName
    albumName="YT "+playlistName
    if not os.path.exists(path):
        os.makedirs(path)
    trackNumber = len([f for f in os.listdir(path) if f.endswith('.mp3')])

    ydl_opts = {
            'addmetadata': True,
            }  
    results = youtube_dl.YoutubeDL(ydl_opts).extract_info(url,download=False)
    if not results:
       warningInfo="ERROR: not extract_info in results"
       print (bcolors.FAIL + warningInfo + bcolors.ENDC)
       return

    artistList = [i['artist'] for i in results['entries']]
    playlistIndexList = [i['playlist_index'] for i in results['entries']]
    songsTitleList = [i['title'] for i in results['entries']]
    for x in range(len(songsTitleList)):
        add_metadata_playlist(playlistIndexList[x], playlistName, artistList[x], songsTitleList[x])


def add_metadata_playlist(PLAYLISTS_PATH, trackNumber, playlistName, artist, songName):
    path=PLAYLISTS_PATH+playlistName
    albumName="YT "+playlistName

    mp3ext=".mp3"
    fileName="%s%s"%(songName,mp3ext)
      
    if not os.path.isfile(os.path.join(path, fileName)):
        songName = songName.replace("/", "_")
        songName = songName.replace("|", "_")
        songName = songName.replace("\"", "'")
        songName = songName.replace(":", "-")
        fileName="%s%s"%(songName,mp3ext)
    if not os.path.isfile(os.path.join(path, fileName)):
        songName = rename_song_name(songName)
        fileName="%s%s"%(songName,mp3ext)
    if not os.path.isfile(os.path.join(path, fileName)):
        warningInfo="WARNING: %s not exist"%(fileName)
        print (bcolors.WARNING + warningInfo + bcolors.ENDC)
        return

    newFileName = rename_song_file(path, fileName)
    newSongName = newFileName.replace(".mp3", "")

    metadataSongName = convert_songname_on_metadata(newSongName)
    newFileNameWithPath = os.path.join(path, newFileName)
        
    metatag = EasyID3(newFileNameWithPath)
    metatag['album'] = albumName
    if artist is not None:
        metatag['artist'] = artist
    else:
        metatag['artist'] = metadataSongName['artist']
    metatag['title'] = metadataSongName['title']
    metatag['tracknumber'] = str(trackNumber)
    metatag.save()
    print (bcolors.OKGREEN + "[ID3] Added metadata" + bcolors.ENDC)
    print (newFileNameWithPath)
    audio = MP3(newFileNameWithPath, ID3=EasyID3)
    print (audio.pprint())

def add_metadata_song(MUSIC_PATH, albumName, artist, songName):
    path=MUSIC_PATH

    mp3ext=".mp3"
    fileName="%s%s"%(songName,mp3ext)
      
    if not os.path.isfile(os.path.join(path, fileName)):
        songName = songName.replace("/", "_")
        songName = songName.replace("|", "_")
        songName = songName.replace("\"", "'")
        songName = songName.replace(":", "-")
        fileName="%s%s"%(songName,mp3ext)
    if not os.path.isfile(os.path.join(path, fileName)):
        songName = rename_song_name(songName)
        fileName="%s%s"%(songName,mp3ext)
    if not os.path.isfile(os.path.join(path, fileName)):
        warningInfo="WARNING: %s not exist"%(fileName)
        print (bcolors.WARNING + warningInfo + bcolors.ENDC)
        return

    newFileName = rename_song_file(path, fileName)
    newSongName = newFileName.replace(".mp3", "")

    metadataSongName = convert_songname_on_metadata(newSongName)
    newFileNameWithPath = os.path.join(path, newFileName)
        
    metatag = EasyID3(newFileNameWithPath)
    if albumName is not None:
        metatag['album'] = albumName
    if artist is not None:
        metatag['artist'] = artist
    else:
        metatag['artist'] = metadataSongName['artist']
    metatag['title'] = metadataSongName['title']
    metatag.save()
    print (bcolors.OKGREEN + "[ID3] Added metadata" + bcolors.ENDC)
    print (newFileNameWithPath)
    audio = MP3(newFileNameWithPath, ID3=EasyID3)
    print (audio.pprint())
    return newFileNameWithPath


